   
Set define off; 

CREATE OR REPLACE  VIEW Synapse.COMPLETE_DATA_INFO

AS 
(select a.user_id,i.login as user_name, a.sender_id,a.mobile_no,a.message,a.CREDITS,a.LANGUAGE,a.RECEIVED_DATE,a.PRIORITY_ID,a.MODULE_NAME,a.TRANSACTION_ID,a.camp_id,
a.SERVICE_CODE,a.INTERFACE_CODE,b.SENTDATE,b.RMT_TRANSACTION_ID,b.REASON,c.DLR_RECEIVED_TIME,c.DLR_STATUS,c.DLR_REASON,c.ERROR_CODE,d.DEPT_ID,
f.DEPT_NAME,g.CATEGORY_ID,h.CAMP_NAME
from Synapse.TRANS_IN_SMS a left outer join Synapse.TRANS_OUT_SMS b on a.TRANSACTION_ID=b.TRANSACTION_ID
left outer join Synapse.TRANS_DLR_SMS c on b.RMT_TRANSACTION_ID=c.RMT_TRANSACTION_ID
left outer join Synapse.LNK_DEPT_USER d on a.USER_ID=d.USER_ID
left outer join Synapse.DEPARTMENT_INFO f on d.DEPT_ID=f.DEPT_ID
left outer join Synapse.MSG_PRIORITY_INFO g on a.PRIORITY_ID=g.PRIORITY_ID
left outer join Synapse.CAMPAIGN_SMS h on a.CAMP_ID=h.CAMP_ID
left outer join Synapse.USERS_INFO i on a.USER_ID=i.USER_ID);


CREATE OR REPLACE  VIEW Synapse.DASHBOARD_DEPT

AS 
(  SELECT d.PRIORITY_NAME,
              a.PRIORITY_ID,
              f.DEPT_NAME,
              e.DEPT_ID,
              COUNT (a.TRANSACTION_ID)
                  AS incoming,
              COUNT (b.TRANSACTION_ID)
                  AS outgoing,
              COUNT (c.RMT_TRANSACTION_ID)
                  AS delivered,
              COUNT (a.TRANSACTION_ID) - COUNT (b.TRANSACTION_ID)
                  AS pending
         FROM Synapse.TRANS_IN_SMS a
              LEFT OUTER JOIN Synapse.TRANS_OUT_SMS b
                  ON a.TRANSACTION_ID = b.TRANSACTION_ID
              LEFT OUTER JOIN Synapse.TRANS_DLR_SMS c
                  ON     b.RMT_TRANSACTION_ID = c.RMT_TRANSACTION_ID
                     AND c.DLR_STATUS = 'DELIVRD'
              LEFT OUTER JOIN Synapse.MSG_PRIORITY_INFO d
                  ON a.PRIORITY_ID = d.PRIORITY_ID
              LEFT OUTER JOIN Synapse.LNK_DEPT_USER e ON a.USER_ID = e.USER_ID
              LEFT OUTER JOIN Synapse.DEPARTMENT_INFO f
                  ON e.DEPT_ID = f.DEPT_ID
        WHERE RECEIVED_DATE BETWEEN TO_DATE (TRUNC (SYSDATE),
                                             'dd-mm-yy hh24:mi:ss')
                                AND TO_DATE (TRUNC (SYSDATE + 1),
                                             'dd-mm-yy hh24:mi:ss')
     GROUP BY d.PRIORITY_NAME,
              a.PRIORITY_ID,
              f.DEPT_NAME,
              e.DEPT_ID);


CREATE OR REPLACE  VIEW Synapse.DASHBOARD_GLOBAL

AS 
(SELECT d.PRIORITY_NAME,
             a.PRIORITY_ID,
             COUNT (a.TRANSACTION_ID)                                AS incoming,
             COUNT (b.TRANSACTION_ID)                                AS outgoing,
             COUNT (c.RMT_TRANSACTION_ID)                            AS delivered,
             COUNT (a.TRANSACTION_ID) - COUNT (b.TRANSACTION_ID)     AS pending
        FROM Synapse.TRANS_IN_SMS a
             LEFT OUTER JOIN Synapse.TRANS_OUT_SMS b
                 ON a.TRANSACTION_ID = b.TRANSACTION_ID
             LEFT OUTER JOIN Synapse.TRANS_DLR_SMS c
                 ON     b.RMT_TRANSACTION_ID = c.RMT_TRANSACTION_ID
                    AND c.DLR_STATUS = 'DELIVRD'
             LEFT OUTER JOIN Synapse.MSG_PRIORITY_INFO d
                 ON a.PRIORITY_ID = d.PRIORITY_ID
       WHERE RECEIVED_DATE BETWEEN TO_DATE (TRUNC (SYSDATE),'dd-mm-yy hh24:mi:ss') AND TO_DATE (TRUNC (SYSDATE + 1),'dd-mm-yy hh24:mi:ss')
    GROUP BY d.PRIORITY_NAME, a.PRIORITY_ID);


CREATE OR REPLACE  VIEW Synapse.DASHBOARD_USER

AS 
(SELECT d.PRIORITY_NAME,
             a.PRIORITY_ID,
            e.LOGIN        AS user_name,
             a.USER_ID,
             COUNT (a.TRANSACTION_ID)                                AS incoming,
             COUNT (b.TRANSACTION_ID)                                AS outgoing,
             COUNT (c.RMT_TRANSACTION_ID)                            AS delivered,
             COUNT (a.TRANSACTION_ID) - COUNT (b.TRANSACTION_ID)     AS pending
        FROM Synapse.TRANS_IN_SMS a
             LEFT OUTER JOIN Synapse.TRANS_OUT_SMS b
                 ON a.TRANSACTION_ID = b.TRANSACTION_ID
             LEFT OUTER JOIN Synapse.TRANS_DLR_SMS c
                 ON     b.RMT_TRANSACTION_ID = c.RMT_TRANSACTION_ID
                    AND c.DLR_STATUS = 'DELIVRD'
             LEFT OUTER JOIN Synapse.MSG_PRIORITY_INFO d
                 ON a.PRIORITY_ID = d.PRIORITY_ID
             LEFT OUTER JOIN Synapse.users_info e ON a.USER_ID = e.USER_ID
       WHERE RECEIVED_DATE BETWEEN TO_DATE (TRUNC (SYSDATE),'dd-mm-yy hh24:mi:ss') AND TO_DATE (TRUNC (SYSDATE + 1),'dd-mm-yy hh24:mi:ss')
    GROUP BY d.PRIORITY_NAME,
             a.PRIORITY_ID,
             e.LOGIN,
             a.USER_ID);


CREATE OR REPLACE  VIEW Synapse.DAYWISE_VIEW

AS 
(  SELECT Trunc (a.received_date, 'DD')
                  AS date1,
              a.USER_ID,
              b.dept_id,
              COUNT (*)
                  AS cnt,
              ROW_NUMBER ()
                  OVER (
                      ORDER BY
                          trunc (a.received_date, 'DD'), a.user_id)
                  AS rownumber
         FROM Synapse.TRANS_IN_SMS a
              LEFT OUTER JOIN Synapse.LNK_DEPT_USER b ON a.USER_ID = b.USER_ID
     GROUP BY trunc (a.received_date, 'DD'), a.USER_ID, b.dept_id);


CREATE OR REPLACE  VIEW Synapse.VV_AGG_CAMP_TODAY_REPORT

AS 
(  SELECT TRUNC (a.received_date, 'dd')
                  AS date1,
              f.CAMP_NAME,
              a.camp_id,
              h.dept_name,
              e.LOGIN
                  AS user_name,
              a.user_id,
              COUNT (a.TRANSACTION_ID)
                  AS Total_sms,
              COUNT (b.TRANSACTION_ID)
                  AS submitted,
              COUNT ((CASE WHEN c.DLR_STATUS = 'DELIVRD' THEN 'DELIVRD' END))
                  AS DELIVRD,
              COUNT (
                  (CASE
                       WHEN c.DLR_STATUS NOT IN
                                ('DELIVRD', 'Expired', 'Rejected')
                       THEN
                           'UNDELIV'
                   END))
                  AS UNDELIV,
              COUNT ((CASE WHEN c.DLR_STATUS = 'Expired' THEN 'Expired' END))
                  AS Expired,
              COUNT ((CASE WHEN c.DLR_STATUS = 'Rejected' THEN 'Rejected' END))
                  AS Rejected,
              COUNT (a.TRANSACTION_ID) - COUNT (b.TRANSACTION_ID)
                  AS failed
         FROM Synapse.TRANS_IN_SMS a
              LEFT OUTER JOIN Synapse.TRANS_OUT_SMS b
                  ON     a.TRANSACTION_ID = b.TRANSACTION_ID
                     AND b.REASON = 'SUCCESS'
              LEFT OUTER JOIN Synapse.TRANS_DLR_SMS c
                  ON b.RMT_TRANSACTION_ID = c.RMT_TRANSACTION_ID
              LEFT OUTER JOIN Synapse.MSG_PRIORITY_INFO d
                  ON a.PRIORITY_ID = d.PRIORITY_ID
              LEFT OUTER JOIN Synapse.users_info e ON e.USER_ID = a.USER_ID
              LEFT OUTER JOIN Synapse.campaign_sms f
                  ON f.camp_id = a.camp_id
              LEFT OUTER JOIN Synapse.LNK_DEPT_USER g
                  ON g.user_id = a.user_id
              LEFT OUTER JOIN Synapse.department_info h
                  ON g.dept_id = h.dept_id
        WHERE a.MODULE_NAME = 'CAMPAIGN'
     GROUP BY TRUNC (a.received_date, 'dd'),
              f.CAMP_NAME,
              a.camp_id,
              h.dept_name,
              c.DLR_STATUS,
              e.LOGIN,
              a.user_id);


CREATE OR REPLACE  VIEW Synapse.VV_AGG_DEPT_TODAY_REPORT

AS 
(  SELECT TRUNC (a.received_date, 'dd')
                  AS date1,
              h.dept_name,
              g.dept_id,
              COUNT (a.TRANSACTION_ID)
                  AS Total_sms,
              COUNT (b.TRANSACTION_ID)
                  AS submitted,
              COUNT ((CASE WHEN c.DLR_STATUS = 'DELIVRD' THEN 'DELIVRD' END))
                  AS DELIVRD,
              COUNT (
                  (CASE
                       WHEN c.DLR_STATUS NOT IN
                                ('DELIVRD', 'Expired', 'Rejected')
                       THEN
                           'UNDELIV'
                   END))
                  AS UNDELIV,
              COUNT ((CASE WHEN c.DLR_STATUS = 'Expired' THEN 'Expired' END))
                  AS Expired,
              COUNT ((CASE WHEN c.DLR_STATUS = 'Rejected' THEN 'Rejected' END))
                  AS Rejected,
              COUNT (a.TRANSACTION_ID) - COUNT (b.TRANSACTION_ID)
                  AS failed,
              ROW_NUMBER ()
                  OVER (ORDER BY TRUNC (a.received_date, 'dd'), g.dept_id)
                  AS rownumber
         FROM Synapse.TRANS_IN_SMS a
              LEFT OUTER JOIN Synapse.TRANS_OUT_SMS b
                  ON     a.TRANSACTION_ID = b.TRANSACTION_ID
                     AND b.REASON = 'SUCCESS'
              LEFT OUTER JOIN Synapse.TRANS_DLR_SMS c
                  ON b.RMT_TRANSACTION_ID = c.RMT_TRANSACTION_ID
              LEFT OUTER JOIN Synapse.LNK_DEPT_USER g ON g.user_id = a.user_id
              LEFT OUTER JOIN Synapse.department_info h
                  ON g.dept_id = h.dept_id
        WHERE h.DEPT_id IS NOT NULL
     GROUP BY TRUNC (a.received_date, 'dd'), h.dept_name, g.dept_id);


CREATE OR REPLACE  VIEW Synapse.VV_AGG_INTERFACE_TODAY_REPORT

AS 
(  SELECT TRUNC (a.received_date, 'dd')
                  AS date1,
              a.USER_ID,
              g.INTERFACE_NAME,
              a.interface_code,
              COUNT (a.TRANSACTION_ID)
                  AS total_sms,
              COUNT (b.TRANSACTION_ID)
                  AS submitted,
              COUNT ((CASE WHEN c.DLR_STATUS = 'DELIVRD' THEN 'DELIVRD' END))
                  AS DELIVRD,
              COUNT (
                  (CASE
                       WHEN c.DLR_STATUS NOT IN
                                ('DELIVRD', 'Expired', 'Rejected')
                       THEN
                           'UNDELIV'
                   END))
                  AS UNDELIV,
              COUNT ((CASE WHEN c.DLR_STATUS = 'Expired' THEN 'Expired' END))
                  AS Expired,
              COUNT ((CASE WHEN c.DLR_STATUS = 'Rejected' THEN 'Rejected' END))
                  AS Rejected,
              COUNT ((CASE WHEN c.DLR_STATUS = 'Enroute' THEN 'Enroute' END))
                  AS Enroute,
              COUNT (a.TRANSACTION_ID) - COUNT (b.TRANSACTION_ID)
                  AS failed,
              ROW_NUMBER ()
                  OVER (
                      ORDER BY
                          TRUNC (a.received_date, 'dd'),
                          a.interface_code,
                          a.USER_ID)
                  AS rownumber
         FROM Synapse.TRANS_IN_SMS a
              LEFT OUTER JOIN Synapse.TRANS_OUT_SMS b
                  ON     a.TRANSACTION_ID = b.TRANSACTION_ID
                     AND b.REASON = 'SUCCESS'
              LEFT OUTER JOIN Synapse.TRANS_DLR_SMS c
                  ON b.RMT_TRANSACTION_ID = c.RMT_TRANSACTION_ID
              LEFT OUTER JOIN Synapse.INTERFACE_INFO g
                  ON a.interface_code = g.interface_code
        WHERE a.INTERFACE_CODE IS NOT NULL
     GROUP BY TRUNC (a.received_date, 'dd'),
              a.USER_ID,
              g.INTERFACE_NAME,
              a.interface_code);


CREATE OR REPLACE  VIEW Synapse.VV_AGG_SERVICECODE_TODAY_REPORT

AS 
(  SELECT TRUNC (a.received_date, 'dd')
                  AS date1,
              a.USER_ID,
              g.Service_name,
              a.SERVICE_CODE,
              COUNT (a.TRANSACTION_ID)
                  AS total_sms,
              COUNT (b.TRANSACTION_ID)
                  AS submitted,
              COUNT ((CASE WHEN c.DLR_STATUS = 'DELIVRD' THEN 'DELIVRD' END))
                  AS DELIVRD,
              COUNT (
                  (CASE
                       WHEN c.DLR_STATUS NOT IN
                                ('DELIVRD', 'Expired', 'Rejected')
                       THEN
                           'UNDELIV'
                   END))
                  AS UNDELIV,
              COUNT ((CASE WHEN c.DLR_STATUS = 'Expired' THEN 'Expired' END))
                  AS Expired,
              COUNT ((CASE WHEN c.DLR_STATUS = 'Rejected' THEN 'Rejected' END))
                  AS Rejected,
              COUNT ((CASE WHEN c.DLR_STATUS = 'Enroute' THEN 'Enroute' END))
                  AS Enroute,
              COUNT (a.TRANSACTION_ID) - COUNT (b.TRANSACTION_ID)
                  AS failed,
              ROW_NUMBER ()
                  OVER (
                      ORDER BY
                          TRUNC (a.received_date, 'dd'),
                          a.USER_ID,
                          a.service_code)
                  AS rownumber
         FROM Synapse.TRANS_IN_SMS a
              LEFT OUTER JOIN Synapse.TRANS_OUT_SMS b
                  ON     a.TRANSACTION_ID = b.TRANSACTION_ID
                     AND b.REASON = 'SUCCESS'
              LEFT OUTER JOIN Synapse.TRANS_DLR_SMS c
                  ON b.RMT_TRANSACTION_ID = c.RMT_TRANSACTION_ID
              LEFT OUTER JOIN Synapse.SERVICE_INFO g
                  ON a.SERVICE_CODE = g.SERVICE_CODE
        WHERE a.SERVICE_CODE IS NOT NULL
     GROUP BY TRUNC (a.received_date, 'dd'),
              a.USER_ID,
              g.SERVICE_NAME,
              a.SERVICE_CODE);


CREATE OR REPLACE  VIEW Synapse.VV_AGG_USER_TODAY_REPORT

AS 
(  SELECT TRUNC (a.received_date, 'dd')
                  AS date1,
              h.dept_name,
              g.dept_id,
              e.LOGIN
                  AS user_name,
              a.user_id,
              COUNT (a.TRANSACTION_ID)
                  AS base_uploaded,
              COUNT (b.TRANSACTION_ID)
                  AS sent,
              COUNT (c.RMT_TRANSACTION_ID)
                  AS delivered,
              COUNT (a.TRANSACTION_ID) - COUNT (c.RMT_TRANSACTION_ID)
                  AS failed
         FROM Synapse.TRANS_IN_SMS a
              LEFT OUTER JOIN Synapse.TRANS_OUT_SMS b
                  ON a.TRANSACTION_ID = b.TRANSACTION_ID
              LEFT OUTER JOIN Synapse.TRANS_DLR_SMS c
                  ON     b.RMT_TRANSACTION_ID = c.RMT_TRANSACTION_ID
                     AND c.DLR_STATUS = 'DELIVRD'
              LEFT OUTER JOIN Synapse.users_info e ON e.USER_ID = a.USER_ID
              LEFT OUTER JOIN Synapse.LNK_DEPT_USER g ON g.user_id = a.user_id
              LEFT OUTER JOIN Synapse.department_info h
                  ON g.dept_id = h.dept_id
        WHERE a.received_date BETWEEN TO_DATE (TRUNC (SYSDATE),
                                               'dd-mm-yy hh24:mi:ss')
                                  AND TO_DATE (TRUNC (SYSDATE + 1),
                                               'dd-mm-yy hh24:mi:ss')
     GROUP BY TRUNC (a.received_date, 'dd'),
              h.dept_name,
              g.dept_id,
              e.LOGIN,
              a.user_id);
