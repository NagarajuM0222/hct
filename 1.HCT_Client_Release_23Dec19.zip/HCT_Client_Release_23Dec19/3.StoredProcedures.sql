
Set define off; 


CREATE OR REPLACE PROCEDURE Synapse.SP_AGG_CAMP_REPORT as

begin

delete from Synapse.AGG_CAMP_REPORT where camp_date between TO_date(TRUNC(SYSDATE -1) ,'dd-mm-yy hh24:mi:ss')  and TO_date(TRUNC(SYSDATE ) ,'dd-mm-yy hh24:mi:ss');

insert into Synapse.AGG_CAMP_REPORT (camp_date,camp_name,camp_id,dept_name,user_name,user_id,base_upload,sent,
delivered,failed)

select cast(a.received_date as date) as date1,f.CAMP_NAME,a.camp_id,h.dept_name,CONCAT(CONCAT(e.firstname, ' '),e.lastname)
as user_name
,a.user_id,count(a.TRANSACTION_ID) as base_uploaded,count(b.TRANSACTION_ID)as sent,count(c.RMT_TRANSACTION_ID) as delivered 
,count(a.TRANSACTION_ID)-count(c.RMT_TRANSACTION_ID) as failed
from Synapse.TRANS_IN_SMS a 
left outer join Synapse.TRANS_OUT_SMS b on a.TRANSACTION_ID=b.TRANSACTION_ID
left outer join Synapse.TRANS_DLR_SMS c on b.RMT_TRANSACTION_ID=c.RMT_TRANSACTION_ID and c.DLR_STATUS='DELIVRD'
left outer join Synapse.MSG_PRIORITY_INFO d on a.PRIORITY_ID=d.PRIORITY_ID 
left outer join Synapse.users_info e on e.USER_ID=a.USER_ID 
left outer join Synapse.campaign_sms f on f.camp_id=a.camp_id
left outer join Synapse.LNK_DEPT_USER g on g.user_id=a.user_id
left outer join Synapse.department_info h on g.dept_id=h.dept_id
where a.received_date between TO_date(TRUNC(SYSDATE -1) ,'dd-mm-yy hh24:mi:ss')  and TO_date(TRUNC(SYSDATE ) ,'dd-mm-yy hh24:mi:ss')
and  a.MODULE_NAME='CAMPAIGN'
group by
cast(a.received_date as date),f.CAMP_NAME,a.camp_id,h.dept_name,CONCAT(CONCAT(e.firstname, ' '),e.lastname)
,a.user_id;
commit;
end;
/
SHOW ERRORS;


CREATE OR REPLACE PROCEDURE Synapse.SP_AGG_DEPT_REPORT as


begin
delete from Synapse.AGG_DEPT_REPORT where DEPT_DATE between TO_date(TRUNC(SYSDATE -1) ,'dd-mm-yy hh24:mi:ss')  and TO_date(TRUNC(SYSDATE ) ,'dd-mm-yy hh24:mi:ss');

insert into Synapse.AGG_DEPT_REPORT(DEPT_DATE,DEPT_NAME,DEPT_ID,BASE_UPLOAD,SENT,DELIVERED,FAILED)

select cast(a.received_date as date) as date1,h.dept_name,g.dept_id,
count(a.TRANSACTION_ID)as base_uploaded,count(b.TRANSACTION_ID)as sent,count(c.RMT_TRANSACTION_ID) as delivered ,count(a.TRANSACTION_ID)-count(c.RMT_TRANSACTION_ID) as failed
from Synapse.TRANS_IN_SMS a 
left outer join Synapse.TRANS_OUT_SMS b on a.TRANSACTION_ID=b.TRANSACTION_ID
left outer join Synapse.TRANS_DLR_SMS c on b.RMT_TRANSACTION_ID=c.RMT_TRANSACTION_ID and c.DLR_STATUS='DELIVRD'
left outer join Synapse.LNK_DEPT_USER g on g.user_id=a.user_id
left outer join Synapse.department_info h on g.dept_id=h.dept_id
where a.received_date between TO_date(TRUNC(SYSDATE -1) ,'dd-mm-yy hh24:mi:ss')  and TO_date(TRUNC(SYSDATE ) ,'dd-mm-yy hh24:mi:ss')
and  h.DEPT_id is not null
group by 
cast(a.received_date as date),h.dept_name,g.dept_id;
commit;
end;

/
SHOW ERRORS;


CREATE OR REPLACE PROCEDURE Synapse.SP_AGG_INTERFACE_REPORT as

begin

delete from Synapse.AGG_INTERFACE_REPORT where interface_date between TO_date(TRUNC(SYSDATE -1) ,'dd-mm-yy hh24:mi:ss')  and TO_date(TRUNC(SYSDATE ) ,'dd-mm-yy hh24:mi:ss');

Insert into AGG_INTERFACE_REPORT(interface_date,interface_name,INTERFACE_CODE,BASE_UPLOAD,SENT,DELIVERED,FAILED)
select cast(a.received_date as date) as date1,g.INTERFACE_NAME,g.interface_code,
count(a.TRANSACTION_ID)as base_uploaded,count(b.TRANSACTION_ID)as sent,count(c.RMT_TRANSACTION_ID) as delivered ,count(a.TRANSACTION_ID)-count(c.RMT_TRANSACTION_ID) as failed
from Synapse.TRANS_IN_SMS a 
left outer join Synapse.TRANS_OUT_SMS b on a.TRANSACTION_ID=b.TRANSACTION_ID
left outer join Synapse.TRANS_DLR_SMS c on b.RMT_TRANSACTION_ID=c.RMT_TRANSACTION_ID and c.DLR_STATUS='DELIVRD'
left outer join Synapse.INTERFACE_INFO g on a.interface_code=g.interface_code
where a.received_date between TO_date(TRUNC(SYSDATE -1) ,'dd-mm-yy hh24:mi:ss')  and TO_date(TRUNC(SYSDATE ) ,'dd-mm-yy hh24:mi:ss')
and a.INTERFACE_CODE is not null
group by 
cast(a.received_date as date),g.INTERFACE_NAME,g.interface_code;
commit;
end;

/
SHOW ERRORS;


CREATE OR REPLACE PROCEDURE Synapse.SP_AGG_USER_REPORT as

begin

delete from Synapse.AGG_USER_REPORT where USER_DATE between TO_date(TRUNC(SYSDATE -1) ,'dd-mm-yy hh24:mi:ss')  and TO_date(TRUNC(SYSDATE ) ,'dd-mm-yy hh24:mi:ss');
Insert into Synapse.AGG_USER_REPORT (USER_DATE,DEPT_NAME,DEPT_ID,USER_NAME,USER_ID,BASE_UPLOAD,SENT,DELIVERED,FAILED)
select cast(a.received_date as date) as date1,h.dept_name,g.dept_id,CONCAT(CONCAT(e.firstname, ' '),e.lastname)as user_name
,a.user_id,
count(a.TRANSACTION_ID)as base_uploaded,count(b.TRANSACTION_ID)as sent,count(c.RMT_TRANSACTION_ID) as delivered ,count(a.TRANSACTION_ID)-count(c.RMT_TRANSACTION_ID) as failed
from Synapse.TRANS_IN_SMS a 
left outer join Synapse.TRANS_OUT_SMS b on a.TRANSACTION_ID=b.TRANSACTION_ID
left outer join Synapse.TRANS_DLR_SMS c on b.RMT_TRANSACTION_ID=c.RMT_TRANSACTION_ID and c.DLR_STATUS='DELIVRD'
left outer join Synapse.users_info e on e.USER_ID=a.USER_ID 
left outer join Synapse.LNK_DEPT_USER g on g.user_id=a.user_id
left outer join Synapse.department_info h on g.dept_id=h.dept_id
where a.received_date between TO_date(TRUNC(SYSDATE -1) ,'dd-mm-yy hh24:mi:ss')  and TO_date(TRUNC(SYSDATE ) ,'dd-mm-yy hh24:mi:ss')
group by 
cast(a.received_date as date),h.dept_name,g.dept_id,CONCAT(CONCAT(e.firstname, ' '),e.lastname),a.user_id;
commit;

end;
/
SHOW ERRORS;


CREATE OR REPLACE PROCEDURE Synapse.SP_smshosttxns (
        p_MESSAGE_ID NVARCHAR2,
	  p_USER_ID number,
	   p_mobile_no nvarchar2,
       p_message nvarchar2,
       p_DataEncoding number,
       p_ServiceCode nvarchar2,
	   p_interface_code nvarchar2,
        p_sender_id VARCHAR2)

AS 
BEGIN
 
  INSERT INTO Synapse.smshosttxns (MESSAGE_ID, USER_ID, MOBILE_NO, MESSAGE,DATAENCODING,SERVICE_CODE,INTERFACE_CODE,SENDER_ID,INSERT_TIME) 
  VALUES (p_MESSAGE_ID, p_USER_ID,p_mobile_no,p_message,p_DataEncoding,p_ServiceCode,p_interface_code,p_sender_id,sysdate);
  commit;
 


END SP_smshosttxns;
/
SHOW ERRORS;
